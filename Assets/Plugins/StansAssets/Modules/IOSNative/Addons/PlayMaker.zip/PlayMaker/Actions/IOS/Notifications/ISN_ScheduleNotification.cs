﻿using UnityEngine;
using System;
using System.Collections;
using HutongGames.PlayMaker;
	
namespace HutongGames.PlayMaker.Actions {
		
	[ActionCategory("IOS Native - Notifications")]
	public class ISN_ScheduleNotification : FsmStateAction {

		public FsmInt time;
		public FsmString message;
		public FsmBool sound;
		public FsmInt badges;
		
		public override void OnEnter() {
		
			ISN_LocalNotification notification =  new ISN_LocalNotification(DateTime.Now.AddSeconds(time.Value), message.Value, sound.Value);

			if(badges.Value > 0) {
				notification.SetBadgesNumber(badges.Value);
			}

			notification.Schedule();

			Finish();
		}
	}
}
