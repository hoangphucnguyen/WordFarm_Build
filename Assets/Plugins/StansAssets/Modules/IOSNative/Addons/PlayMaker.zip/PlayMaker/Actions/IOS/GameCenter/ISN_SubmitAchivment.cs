﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Center")]
	public class ISN_SubmitAchivment : FsmStateAction {

		public FsmString achivmentId;
		public bool showNotification;
		public FsmFloat progress;

		public bool UseCustomNotification = false;
		public FsmString NotificationText;



		public override void OnEnter() {
			GameCenterManager.SubmitAchievement(progress.Value, achivmentId.Value, showNotification);

			if(UseCustomNotification) {
				ISN_LocalNotificationsController.Instance.ShowGmaeKitNotification("Achievement Unlocked", NotificationText.Value);
			}
			Finish();
		}

	}
}

