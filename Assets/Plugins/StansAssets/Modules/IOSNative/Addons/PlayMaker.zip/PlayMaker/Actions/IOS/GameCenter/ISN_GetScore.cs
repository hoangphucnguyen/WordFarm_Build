﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Center")]
	public class ISN_GetScore : FsmStateAction {

		public FsmString leaderboardId;
		public FsmInt score;


		public override void OnEnter() {

			GK_Leaderboard board = GameCenterManager.GetLeaderboard(leaderboardId.Value);
			if(board != null) {
				GK_Score s =  board.GetCurrentPlayerScore(GK_TimeSpan.ALL_TIME, GK_CollectionType.GLOBAL);
				if(s != null) {
					Debug.Log("ISN_GetScore: Score was already loaded");
					score.Value = (int) s.LongScore;
					Finish();
					return;
				}

			}

			SendScoreLoadRequest();


			
		}

		private void SendScoreLoadRequest() {
			Debug.Log("ISN_GetScore: Sending score Request");


			GameCenterManager.OnLeadrboardInfoLoaded += OnPlayerScoreLoaded;
			GameCenterManager.LoadLeaderboardInfo(leaderboardId.Value);
		}

		private void OnPlayerScoreLoaded (GK_LeaderboardResult res) {
			if(res.IsSucceeded) {
				score.Value = (int) res.Leaderboard.GetCurrentPlayerScore(GK_TimeSpan.ALL_TIME, GK_CollectionType.GLOBAL).LongScore;
			} else {
				score.Value = 0;
			}
			Finish();

		}

	}
}

