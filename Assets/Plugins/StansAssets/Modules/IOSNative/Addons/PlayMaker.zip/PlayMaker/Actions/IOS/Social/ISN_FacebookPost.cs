using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Social")]
	public class ISN_FacebookPost : FsmStateAction {
		
		public FsmString message;
		public FsmString url;


		public FsmTexture texture;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			

			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}


			IOSSocialManager.OnFacebookPostResult += HandleOnFacebookPostResult;

			IOSSocialManager.Instance.FacebookPost(message.Value, url.Value, texture.Value as Texture2D);
			
		}

		void HandleOnFacebookPostResult (SA.Common.Models.Result res) {
			if(res.IsSucceeded) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}

			IOSSocialManager.OnFacebookPostResult -= HandleOnFacebookPostResult;
			Finish();
		}

		public override void Reset() {
			base.Reset();
			message   = "Message Text";
		}

		
		
	}
}



