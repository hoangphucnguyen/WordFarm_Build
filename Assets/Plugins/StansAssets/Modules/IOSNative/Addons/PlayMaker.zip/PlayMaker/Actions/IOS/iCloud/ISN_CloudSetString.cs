﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("IOS Native - iCloud")]
	public class ISN_CloudSetString : FsmStateAction {
		public FsmString key;
		public FsmString value;

		public FsmEvent successEvent;

		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			iCloudManager.Instance.setString (key.Value, value.Value);

			Finish();
		}

	}
}
