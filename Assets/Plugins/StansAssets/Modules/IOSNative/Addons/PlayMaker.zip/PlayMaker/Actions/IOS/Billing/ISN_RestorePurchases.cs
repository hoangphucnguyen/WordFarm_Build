using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using SA.IOSNative.StoreKit;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Restore purchases, resotred event will be fired for ectach restored purchase")]
	public class ISN_RestorePurchases : FsmStateAction {
		
				


		public FsmString[] restoredProducts;
		public FsmString   currentRestoredItem;

		[Tooltip("Event fired when Store Kit product restored")]
		public FsmEvent successEvent;
		
		[Tooltip("Event fired when Store Kit purchase is failed")]
		public FsmEvent failEvent;

		[Tooltip("Event fired when Store Kit purchase is failed")]
		public FsmEvent ItemRestoredEvent;


		private List<FsmString> restoredProductsCash =  new List<FsmString>();


		public override void Reset() {
			restoredProductsCash = new List<FsmString>();
		}


		public override void OnEnter() {

			new BillingInitChecker(OnBillingInit);

			#if UNITY_EDITOR
			Fsm.Event(successEvent);
			Finish();
			return;
			#endif
			
		}

		private void OnBillingInit() {

			PaymentManager.OnTransactionComplete += OnTransactionComplete;
			PaymentManager.OnRestoreComplete += HandleOnRestoreComplete;
			PaymentManager.Instance.RestorePurchases();
		}





		void OnTransactionComplete (PurchaseResult resp) {


			switch(resp.State) {
			case PurchaseState.Purchased:
			case PurchaseState.Restored:
				restoredProductsCash.Add(resp.ProductIdentifier);
				currentRestoredItem.Value = resp.ProductIdentifier;
				Fsm.Event(ItemRestoredEvent);
				break;
			case PurchaseState.Deferred:
			case PurchaseState.Failed:
				Fsm.Event(failEvent);
				break;
			}


		}

		void HandleOnRestoreComplete (RestoreResult res) {
			PaymentManager.OnTransactionComplete -= OnTransactionComplete;
			PaymentManager.OnRestoreComplete -= HandleOnRestoreComplete;
			
			
			restoredProducts = restoredProductsCash.ToArray ();
			Fsm.Event(successEvent);
			Finish();
		}

		
	
		
	}
}




