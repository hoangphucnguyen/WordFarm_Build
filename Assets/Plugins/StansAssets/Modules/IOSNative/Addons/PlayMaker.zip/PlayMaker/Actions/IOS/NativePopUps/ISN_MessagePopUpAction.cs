﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Pop-ups")]
	[Tooltip("Init Game Center. Best practice to do this on appplicaton start")]
	public class ISN_MessagePopUpAction : FsmStateAction {
		
		public FsmString title;
		public FsmString message;


		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Finish();
				return;
			}

			IOSMessage msg = IOSMessage.Create(title.Value, message.Value);
			msg.OnComplete += HandleOnComplete;
			
		}

		void HandleOnComplete () {
			Finish();
		}

		public override void Reset() {
			base.Reset();
			
			title =  "Message title";
			message   = "Message Text";
			
		}
		
	}
}


