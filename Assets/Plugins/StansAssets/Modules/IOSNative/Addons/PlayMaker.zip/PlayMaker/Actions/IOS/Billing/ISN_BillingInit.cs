using UnityEngine;
using System.Collections;
using SA.IOSNative.StoreKit;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Init billing. Best practice to do this on appplicaton start")]
	public class ISN_BillingInit : FsmStateAction {


		[Tooltip("Event fired when Store Kit initlization is complete")]
		public FsmEvent successEvent;

		[Tooltip("Event fired when Store Kit initlization is failed")]
		public FsmEvent failEvent;

		public override void Reset() {
		
		}



		public override void OnEnter() {

			PaymentManager.OnStoreKitInitComplete += OnStoreKitInitComplete;
			PaymentManager.Instance.LoadStore();

		}

		private void OnStoreKitInitComplete (SA.Common.Models.Result res) {
			PaymentManager.OnStoreKitInitComplete -= OnStoreKitInitComplete;
			if(res.IsSucceeded) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}


			Finish();
		}



	}
}

