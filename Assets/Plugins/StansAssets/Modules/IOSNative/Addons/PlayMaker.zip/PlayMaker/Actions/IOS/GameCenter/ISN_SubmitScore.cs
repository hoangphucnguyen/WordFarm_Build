﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Center")]
	public class ISN_SubmitScore : FsmStateAction {

		public FsmString leaderboardId;
		public FsmInt score;
		public FsmInt context;


		public override void OnEnter() {
			GameCenterManager.ReportScore(score.Value, leaderboardId.Value, context.Value);
			Finish();
			
		}

	}
}

