﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - iCloud")]
	public class ISN_CloudRequestDataForKey : FsmStateAction {
		
		public FsmEvent successEvent;

		public FsmString key;

		public FsmString data;

		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			iCloudManager.OnCloudDataReceivedAction += HandleOnCloudDataReceivedAction;
			iCloudManager.Instance.requestDataForKey (key.Value);
		}

		void HandleOnCloudDataReceivedAction (iCloudData cloudData) {

			if(cloudData.key.Equals(key.Value)) {
				iCloudManager.OnCloudDataReceivedAction -= HandleOnCloudDataReceivedAction;
				data.Value = cloudData.stringValue;

				Fsm.Event(successEvent);
				Finish();
			}
		}


		void OnDestroy() {
			iCloudManager.OnCloudDataReceivedAction -= HandleOnCloudDataReceivedAction;
		}
	}
}
